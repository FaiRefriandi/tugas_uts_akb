package com.froztlass.utsakb

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editTextDate: EditText = findViewById(R.id.editTextDate)
        val editTextDate2: EditText = findViewById(R.id.editTextDate2)
        val radioGroup: RadioGroup = findViewById(R.id.radioGroup)

        editTextDate.setOnClickListener {
            showDatePickerDialog(editTextDate)
        }

        editTextDate2.setOnClickListener {
            showDatePickerDialog(editTextDate2)
        }

        val nextButton = findViewById<TextView>(R.id.next)
        nextButton.setOnClickListener {
            val radioGroupResult = when (radioGroup.checkedRadioButtonId) {
                R.id.radioButton8 -> "Laki-laki"
                R.id.radioButton9 -> "Perempuan"
                else -> ""
            }

            val editTextResult = editTextDate2.text.toString()

            val intent = Intent(this, ResultActivity::class.java)
            intent.putExtra("radioGroupResult", radioGroupResult)
            intent.putExtra("editTextResult", editTextResult)
            startActivity(intent)
        }
    }

    private fun showDatePickerDialog(editText: EditText) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
            val selectedDate = "${selectedDay}/${selectedMonth + 1}/${selectedYear}"
            editText.setText(selectedDate)
        }, year, month, day)

        datePickerDialog.show()
    }
}
