package com.froztlass.utsakb

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ResultActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        val textViewRadioGroup = findViewById<TextView>(R.id.textViewRadioGroup)
        val textViewEditText = findViewById<TextView>(R.id.textViewEditText)

        val bundle = intent.extras
        val radioGroupResult = bundle?.getString("radioGroupResult")
        val editTextResult = bundle?.getString("editTextResult")

        textViewRadioGroup.text = "Jenis Kelamin: $radioGroupResult"
        textViewEditText.text = "Tanggal Lahir: $editTextResult"
    }
}
